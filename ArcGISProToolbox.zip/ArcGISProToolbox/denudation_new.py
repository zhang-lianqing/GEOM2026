# ==========================================================================================================
# denudation_new.py
# Purpose:      Calculate catchment-wide denudation rates using the new framework:
#               1. Constrain the coefficients(k) in denudation models
#               2. Apply the constrained coefficients and denudation models to a catchment 
#                   for denudation, physical erosion and chemical weathering rates calculations.
#
# Author:       Lianqing Zhang (lianqingzhang2023@gmail.com)
#
# Created:      2026.3
# Copyright (c) 2026 Lianqing Zhang
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, provided that the above copyright notice and this
# permission notice shall be included in all copies or substantial portions of
# the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==========================================================================================================
# Denudation models | Denudation (D) = Chemical Weathering (W) + Physical Erosion (E)
# ==========================================================================================================

import arcpy
import os
import sys
import numpy as np
import pandas as pd
import tempfile
import shutil
from scipy.optimize import curve_fit

# Get the directory (cur_dir) of this script
cur_dir = os.path.dirname(os.path.abspath(__file__))
#  then, add it into the system path
sys.path.append(cur_dir)
#  to access the data base and unitilty functions.
from data_base import *
from utility_functions import *

# Check licenses.
arcpy.CheckOutExtension('Spatial')
# clean up in memeory
arcpy.Delete_management("in_memory")
# setting environment
arcpy.env.overwriteOutput = True
# setting temporary folder
temp_folder = tempfile.mkdtemp()

# ==========================================================================================================

def calculate_weathering(weathering, SLP_array):
    """
    Calculate chemical weathering distribution based on slope-dependent scenarios.

    Parameters:
    - weathering: scalar or array representing baseline weathering rate
    - SLP_array: array of slope values

    Returns:
    - chemicalweathering: array of weathering values adjusted by slope
    """

    # Compute the 95th percentile of slope (ignoring NaNs)
    slp_large = np.nanpercentile(SLP_array, 95)

    # Handle edge cases (e.g., flat terrain or all-NaN input)
    if slp_large == 0 or np.isnan(slp_large):
        return np.zeros_like(SLP_array)

    # Clip slope values at the 95th percentile to avoid negative results
    SLP_clipped = np.minimum(SLP_array, slp_large)

    # Scenario #1: weathering decreases linearly with slope (no negative values)
    # chemicalweathering = weathering * (1 - SLP_clipped / slp_large)

    # Scenario #2: weathering increases with slope (also clipped for consistency)
    # chemicalweathering = weathering * (SLP_clipped / slp_large)

    # Scenario #3: constant weathering across the catchment
    chemicalweathering = 0.2 * weathering * np.ones_like(SLP_array)

    # Scenario #4: negligible weathering
    # chemicalweathering = np.zeros_like(SLP_array)

    return chemicalweathering

# ==========================================================================================================

def calculate_erosion(k, SLP_array, base_value):
    """
    calculate physical erosion array(distribution) using erosion equations
    """
    physicalerosion = k * (SLP_array ** 1.75) + base_value

    return physicalerosion

# ==========================================================================================================

def obtain_k_bounds(DEM_array, SLP_array, centroid_lat, centroid_long, concentration_CN, 
                    Density, shielding_factor_field, chemicalweathering):
    """
    estimate initial k bounds
    """
    # mean values as reference values
    elevation_mean = np.nanmean(DEM_array)
    slope_mean = np.nanmean(SLP_array)

    # calculate a denudation for reference
    denudation = calculate_denudation_rate_point(centroid_lat, centroid_long, elevation_mean, 
                                                 concentration_CN, Density, shielding_factor_field)
    # estimate chemical weathering
    weathering_mean = np.nanmean(chemicalweathering)

    # k large
    k_large = denudation*1.25 / (slope_mean**1.75)
    # k small
    if denudation < weathering_mean:
        # to avoid negative k
        k_small = denudation*0.25 / (slope_mean**1.75)
    else:
        k_small = 0.25*(denudation-weathering_mean) / (slope_mean**1.75)
    
    return k_small, k_large

# ==========================================================================================================

def calculate_N(latitude, longitude, lat_array, chemicalweathering, physicalerosion, 
                DEM_array, density, shieldingfactor):
    """
    This function calculates physical erosion-weighted average concentration for the catchment.
    """
    # get production rate of different reaction pathways
    production_rate_catchment_sp, production_rate_catchment_fm, production_rate_catchment_sm = \
    calculate_production_rate_catchment(latitude, longitude, lat_array, DEM_array, shieldingfactor)
    
    # calculate denudation
    denudation_array = chemicalweathering + physicalerosion

    # calculate the physical erosion weighting factor (only physical erosion could contribute sediments to the outlet)
    # Be careful with the NoData in np array.
    weighting_factor = physicalerosion / np.nansum(physicalerosion)

    # calculate the denominator of equation (4) in (Charreau et al., 2019).
    denominator_sp = decay_constant_CN + density * denudation_array / attenuation_neutron
    denominator_fm = decay_constant_CN + density * denudation_array / attenuation_fmuon
    denominator_sm = decay_constant_CN + density * denudation_array / attenuation_smuon

    # calculate the CNs concentration 
    #  produced by different reaction pathways
    N_sp = production_rate_catchment_sp / denominator_sp
    N_fm = production_rate_catchment_fm / denominator_fm
    N_sm = production_rate_catchment_sm / denominator_sm
    #  and summarize them
    N_sum = N_sp + N_fm + N_sm
    
    # calculate the physical erosion-weighted catchment mean CN concentration
    N = np.nansum(N_sum * weighting_factor)

    return N

# ==========================================================================================================

# Get Parameters.
Input_catchments_shapefile = arcpy.GetParameterAsText(0)
Input_DEM_raster = arcpy.GetParameterAsText(1)
Density = float(arcpy.GetParameterAsText(2))
# CNs = arcpy.GetParameterAsText(3) # find it in data_base.py
Concentration_field = arcpy.GetParameterAsText(4)
Concentration_uncertainty_field = arcpy.GetParameterAsText(5)
Shielding_factor_field = arcpy.GetParameterAsText(6)
Shielding_factor_raster = arcpy.GetParameterAsText(7)
Chemical_weathering_field = arcpy.GetParameterAsText(8) # unit: mm/kyr
Chemical_weathering_uncertainty_field = arcpy.GetParameterAsText(9)
Model = arcpy.GetParameterAsText(10)
Output_folder_for_denudation_rasters = arcpy.GetParameterAsText(11)
Output_folder_for_k_N_pairs = arcpy.GetParameterAsText(12)

# ==========================================================================================================

# add centroid coordinate for each catchment.
arcpy.management.CalculateGeometryAttributes(Input_catchments_shapefile, [['cent_long', 'CENTROID_X'], ['cent_lat', 'CENTROID_Y']])
# add fields
arcpy.AddField_management(Input_catchments_shapefile, 'k_c', "FLOAT", "", "", 50)
arcpy.AddField_management(Input_catchments_shapefile, "k_range_c", "TEXT", "", "", 10)
arcpy.AddField_management(Input_catchments_shapefile, 'D_c', 'FLOAT', '', '', 50)
arcpy.AddField_management(Input_catchments_shapefile, 'E_c', 'FLOAT', '', '', 50)
arcpy.AddField_management(Input_catchments_shapefile, 'W_c', 'FLOAT', '', '', 50)

# ==========================================================================================================

# total catchments
total_catchments = int(arcpy.GetCount_management(Input_catchments_shapefile)[0])
# set progress prompt
arcpy.SetProgressor("step", "Running...", 0, total_catchments, 1)

if Model == "D = f(slope)":

    field_name = ["SHAPE@", "OBSID1", "cent_long", "cent_lat", Concentration_field, Concentration_uncertainty_field,
                  Chemical_weathering_field, Chemical_weathering_uncertainty_field, Shielding_factor_field, 
                  "k_c", "k_range_c", "D_c", "E_c", "W_c"]

    with arcpy.da.UpdateCursor(Input_catchments_shapefile, field_name) as cursor:
            # process each catchment
            for index, row in enumerate(cursor, start=1):

                # get attributes
                geometry = row[0]
                FID = row[1]
                centroid_long = row[2]
                centroid_lat = row[3]
                concentration_CN = row[4]
                concentration_uncertainty = row[5]
                chemical_weathering_field = row[6] / 10000 # convert unit from mm/kyr to cm/yr
                chemical_weathering_uncertainty = row[7] / 10000 # convert unit from mm/kyr to cm/yr
                shielding_factor_field = row[8]

                # get the utm projected coordinate system
                utm_spatial_reference = get_utm_project_name(centroid_long, centroid_lat)

                # get the catchment's DEM
                DEM = arcpy.sa.ExtractByMask(Input_DEM_raster, geometry, 'INSIDE')
                # project DEM
                DEM_project = os.path.join(temp_folder, f"DEM_project_{FID}.tif")
                arcpy.management.ProjectRaster(DEM, DEM_project, utm_spatial_reference)
                # calculate slope
                SLP = arcpy.sa.SurfaceParameters(DEM_project,"SLOPE")

                # get DEM array.
                DEM_array = arcpy.RasterToNumPyArray(DEM_project, nodata_to_value=-9999)
                #  convert the DEM array into float data type.
                DEM_array = DEM_array.astype(float)
                #  then, conver the -9999 to NoData.
                DEM_array[DEM_array == -9999] = np.nan
                # get slope array
                SLP_array = arcpy.RasterToNumPyArray(SLP, nodata_to_value=np.nan)
                # get latitude array
                lat_array = get_coordinates_array(DEM, DEM_array)

                # get shielding factor array
                if Shielding_factor_raster:
                    shielding_raster = arcpy.sa.ExtractByMask(Shielding_factor_raster, geometry, 'INSIDE')
                    # project
                    shielding_raster_project = os.path.join(temp_folder, f"shielding_raster_project_{FID}.tif")
                    arcpy.management.ProjectRaster(shielding_raster, shielding_raster_project, utm_spatial_reference)
                    # get shielding factor array
                    shieldingfactor_array = arcpy.RasterToNumPyArray(shielding_raster_project, nodata_to_value=-9999)
                    shieldingfactor_array = shieldingfactor_array.astype(float)
                    shieldingfactor_array[shieldingfactor_array == -9999] = np.nan
                    # check shape
                    if not np.array_equal(shieldingfactor_array.shape, DEM_array.shape):
                        arcpy.AddError('Shielding factor raster has different shape from DEM.')
                    shieldingfactor = shieldingfactor_array
                else:
                    shieldingfactor = shielding_factor_field
                
                # chemical weathering array
                chemicalweathering = calculate_weathering(chemical_weathering_field, SLP_array)

# ==========================================================================================================
                # estimate k bounds
                k_small, k_large = obtain_k_bounds(DEM_array, SLP_array, centroid_lat, centroid_long, concentration_CN, 
                                                    Density, shielding_factor_field, chemicalweathering)
                # get initial k values
                initial_k = np.linspace(k_small, k_large, 12)
                
                # create two empty lists for N and k
                N_value = []
                k_value = []
                for k in initial_k:
                    # physical erosion array
                    physicalerosion = calculate_erosion(k, SLP_array, 
                                                        #base_value=chemical_weathering_field*2*0.5,
                                                        base_value=0
                                                        )
                    N = calculate_N(centroid_lat, centroid_long, lat_array, chemicalweathering,
                                                physicalerosion, DEM_array, Density, shieldingfactor)
                    N_value.append(N)
                    k_value.append(k)

                # convert the unit of k from cm/yr to mm/kyr
                k_value = [x * 10000 for x in k_value]
                
                # get k, N pair
                df_k_N = pd.DataFrame({
                    'k' : k_value,
                    'N' : N_value })
                # save the k and N pairs (optional).
                if Output_folder_for_k_N_pairs:
                    output_path = Output_folder_for_k_N_pairs + '\\' + f'FID_{FID}.csv'
                    df_k_N.to_csv(output_path)
                    
# ==========================================================================================================
                # determine k from measurements
                if min(N_value) <= concentration_CN <= max(N_value):
                    # find the two neighbours of measured CN concentration
                    for i in range(len(N_value) - 1):
                        if N_value[i+1] <= concentration_CN <= N_value[i]:
                            k_value_border = k_value[i:i+2]
                            N_value_border = N_value[i:i+2]
                            parameter_a, parameter_b = np.polyfit(k_value_border, N_value_border, 1)
                            k_best = (concentration_CN - parameter_b) / parameter_a
                            delta_k = concentration_uncertainty / abs(parameter_a)
                            break

                elif concentration_CN > max(N_value) or concentration_CN < min(N_value):
                    parameter_a, parameter_b = np.polyfit(k_value, N_value, 1)
                    k_best = (concentration_CN - parameter_b) / parameter_a
                    delta_k = concentration_uncertainty / abs(parameter_a)

# ==========================================================================================================
                # calculate denudation, erosion, and weathering rates
                # chemical weathering needs to be scaled back to mm/kyr, and k_value has already been scaled to mm/kyr
                erosion_array = calculate_erosion(k_best/10000, SLP_array, 
                                                  #base_value=chemical_weathering_field*2*0.5,
                                                  base_value=0
                                                  ) * 10000
                weathering_array = chemicalweathering * 10000 # unit from cm/yr to mm/kyr
                denudation_array = weathering_array + erosion_array

# ==========================================================================================================
                # output the generated denudation raster (optional).
                if Output_folder_for_denudation_rasters: 
                    describe = arcpy.Describe(SLP)
                    lower_left_corner = arcpy.Point(describe.extent.XMin, describe.extent.YMin)
                    # generate denudation raster
                    denudation_raster = arcpy.NumPyArrayToRaster(denudation_array, lower_left_corner, x_cell_size = SLP, y_cell_size=SLP)
                    weathering_raster = arcpy.NumPyArrayToRaster(weathering_array, lower_left_corner, x_cell_size = SLP, y_cell_size=SLP)
                    erosion_raster     = arcpy.NumPyArrayToRaster(erosion_array, lower_left_corner, x_cell_size = SLP, y_cell_size=SLP)
                    # define projection
                    arcpy.management.DefineProjection(denudation_raster, utm_spatial_reference)
                    arcpy.management.DefineProjection(erosion_raster, utm_spatial_reference)
                    arcpy.management.DefineProjection(weathering_raster, utm_spatial_reference)
                    # save to folder
                    denudation_raster.save(Output_folder_for_denudation_rasters + "\\" + f'FID_{FID}_D.tif')
                    erosion_raster.save(Output_folder_for_denudation_rasters + "\\" + f'FID_{FID}_E.tif')
                    weathering_raster.save(Output_folder_for_denudation_rasters + "\\" + f'FID_{FID}_W.tif')

# ==========================================================================================================
                row[9]  = k_best
                if min(k_value) <= k_best <= max(k_value):
                    row[10] = 'Yes'
                else:
                    row[10] = 'Out'
                row[11] = np.nanmean(denudation_array)
                row[12] = np.nanmean(erosion_array)
                row[13] = np.nanmean(weathering_array)

                cursor.updateRow(row)
                arcpy.SetProgressorPosition(index)
                arcpy.SetProgressorLabel(f"Processing row {index}/{total_catchments}")

# ==========================================================================================================
                    
# clean up
shutil.rmtree(temp_folder)
arcpy.Delete_management("in_memory")

