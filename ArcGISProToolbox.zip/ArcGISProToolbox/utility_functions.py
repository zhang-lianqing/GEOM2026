# =============================================================================
# utility_functions.py
# Purpose:      Provide functions for burial dating
#
# Author:       Lianqing Zhang (lianqingzhang2023@gmail.com)
#               Some of the code is adapted from BASINGA codes by Charreau et al. (2019)
#
# Created:      2026.3
# Copyright (c) 2026 Lianqing Zhang
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, provided that the above copyright notice and this
# permission notice shall be included in all copies or substantial portions of
# the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# =============================================================================
# -*- coding: utf-8 -*-

import arcpy
import os
import sys
import tempfile
import numpy as np
from scipy import interpolate
from scipy.optimize import root_scalar
from scipy.optimize import minimize_scalar

# get the directory (cur_dir) of this script
cur_dir = os.path.dirname(os.path.abspath(__file__))
# add it into the system path
sys.path.append(cur_dir)
# to access the data base
from data_base import *

# ==========================================================================================================

# check licenses
arcpy.CheckOutExtension('Spatial')
# setting
arcpy.env.overwriteOutput = True
# set temporary folder
temp_folder = tempfile.mkdtemp()

# ============================================================================================================

def get_coordinates_array(DEM, DEM_array):
    """
    Get the latitude array of the catchment. This array is used to calculate the Stone coefficient array.

    Input: 
        DEM: catchment DEM
        DEM_array: it comes from the projected DEM.
    Output:
        lat_array: the latitude array of the catchment.
    """
    # get the extent of the catchment on latitude dimension
    desc = arcpy.Describe(DEM) 
    lat_list = np.linspace(desc.extent.YMax, desc.extent.YMin, DEM_array.shape[0])
    lat_array = np.array(lat_list).reshape(-1, 1)
    lat_array = np.tile(lat_array, DEM_array.shape[1])

    return lat_array


def get_Stone_coefficients(latitude):
    """
    References: (Stone, 2000) and (Lal, 1991).

    Input:
        latitude [degrees], either a np.array or a float.
    Outputs:
        a, b, c, d, e : Stone coefficients.
    Note: these factors are used to calculate the spallation (sp) scalling factors only.
            this function is adapted from the BASINGA codes by Charreau et al. (2019).
    """
    # use the absolute value of latitude in case the study area is in southern hemisphere
    latitude = abs(latitude) 

    if isinstance(latitude, np.ndarray):
        latitude_max = latitude.max()
    else:
        latitude_max = latitude

    if latitude_max < 10:
        dec = 10 - latitude
        a = (dec * St[0, 1] + (10 - dec) * St[1, 1]) / 10
        b = (dec * St[0, 2] + (10 - dec) * St[1, 2]) / 10
        c = (dec * St[0, 3] + (10 - dec) * St[1, 3]) / 10
        d = (dec * St[0, 4] + (10 - dec) * St[1, 4]) / 10
        e = (dec * St[0, 5] + (10 - dec) * St[1, 5]) / 10
    elif latitude_max < 20:
        dec = 20 - latitude
        a = (dec * St[1, 1] + (10 - dec) * St[2, 1]) / 10
        b = (dec * St[1, 2] + (10 - dec) * St[2, 2]) / 10
        c = (dec * St[1, 3] + (10 - dec) * St[2, 3]) / 10
        d = (dec * St[1, 4] + (10 - dec) * St[2, 4]) / 10
        e = (dec * St[1, 5] + (10 - dec) * St[2, 5]) / 10
    elif latitude_max < 30:
        dec = 30 - latitude
        a = (dec * St[2, 1] + (10 - dec) * St[3, 1]) / 10
        b = (dec * St[2, 2] + (10 - dec) * St[3, 2]) / 10
        c = (dec * St[2, 3] + (10 - dec) * St[3, 3]) / 10
        d = (dec * St[2, 4] + (10 - dec) * St[3, 4]) / 10
        e = (dec * St[2, 5] + (10 - dec) * St[3, 5]) / 10
    elif latitude_max < 40:
        dec = 40 - latitude
        a = (dec * St[3, 1] + (10 - dec) * St[4, 1]) / 10
        b = (dec * St[3, 2] + (10 - dec) * St[4, 2]) / 10
        c = (dec * St[3, 3] + (10 - dec) * St[4, 3]) / 10
        d = (dec * St[3, 4] + (10 - dec) * St[4, 4]) / 10
        e = (dec * St[3, 5] + (10 - dec) * St[4, 5]) / 10
    elif latitude_max < 50:
        dec = 50 - latitude
        a = (dec * St[4, 1] + (10 - dec) * St[5, 1]) / 10
        b = (dec * St[4, 2] + (10 - dec) * St[5, 2]) / 10
        c = (dec * St[4, 3] + (10 - dec) * St[5, 3]) / 10
        d = (dec * St[4, 4] + (10 - dec) * St[5, 4]) / 10
        e = (dec * St[4, 5] + (10 - dec) * St[5, 5]) / 10
    elif latitude_max < 60:
        dec = 60 - latitude
        a = (dec * St[5, 1] + (10 - dec) * St[6, 1]) / 10
        b = (dec * St[5, 2] + (10 - dec) * St[6, 2]) / 10
        c = (dec * St[5, 3] + (10 - dec) * St[6, 3]) / 10
        d = (dec * St[5, 4] + (10 - dec) * St[6, 4]) / 10
        e = (dec * St[5, 5] + (10 - dec) * St[6, 5]) / 10
    else:
        a = St[6, 1]
        b = St[6, 2]
        c = St[6, 3]
        d = St[6, 4]
        e = St[6, 5]

    return a, b, c, d, e


def get_atmospheric_coefficients(latitude, longitude):
    """
    Calculate the atmospheric parameters at a site, which are used to calculate the sp scaling factor.
    Inputs:
        latitude [degrees]: a float
        longitude [degrees]: a float
    Outputs:
        sea_level_P [hPa]   : sea level atmospheric pressure.
        sea_level_T [K]     : sea level atmospheric temperature.
        ALR [K/m]           : Lifton Adiabatic Lapse Rate (ALR).
    Note: this function is adapted from the BASINGA codes by Charreau et al. (2019).
    """
    # convert the negative longitude to positive
    longitude = (longitude + 360) % 360
    
    sea_level_P = float(interpolate.interp2d(ERA40_lon, ERA40_lat, ERA40_meanP).__call__(longitude, latitude))
    sea_level_T = float(interpolate.interp2d(ERA40_lon, ERA40_lat, ERA40_meanT).__call__(longitude, latitude))

    ALR = ALR_factors[0] + ALR_factors[1] * latitude + ALR_factors[2] * latitude ** 2 + ALR_factors[3] * latitude ** 3 \
           + ALR_factors[4] * latitude ** 4 + ALR_factors[5] * latitude ** 5 + ALR_factors[6] * latitude ** 6
    
    ALR = -ALR

    return sea_level_P, sea_level_T, ALR


def calculate_production_rate_point(latitude, longitude, elevation, shielding_factor_field):
    """
    First, calculate the scaling factor (sp, fast muon reaction (fm), and slow muon capture (sm)).
    Then, calculate the production rate by each reaction pathway at the site (point).

    Input:
        latitude [degrees]
        longtitude [degrees]
        elevation [m]
    Output:
        production_rate_point_sp [atoms/g/yr]    :   the production rate by sp at the site.
        production_rate_point_fm [atoms/g/yr]    :   the production rate by fm at the site.
        production_rate_point_sm [atoms/g/yr]    :   the production rate by sm at the site.
    Note: this function calculates the production rates at a point,
            which can service determining the initial k.
    """

    # get coefficients for sp scaling factor calculation
    sea_level_P, sea_level_T, ALR = get_atmospheric_coefficients(latitude, longitude)
    a, b, c, d, e = get_Stone_coefficients(latitude)

    # convert elevation [m] to atmospheric pressure [hPa]
    P = sea_level_P * np.exp(-0.03417 / ALR * (np.log(sea_level_T) - np.log(sea_level_T - ALR * elevation)))

    # calculate scaling factors
    #  calculate the scaling factor for sp (Stone, 2000)
    scaling_factor_sp = (a + b * np.exp(-P / 150) + c * P + d * P ** 2 + e * P ** 3)
    #  calculate the scaling factors for fm and sm (Braucher et al., 2011)
    scaling_factor_fm = np.exp((1013.25 - P) / atmospheric_attenuation_fm)
    scaling_factor_sm = np.exp((1013.25 - P) / atmospheric_attenuation_sm)

    # calculate the production rate at the site
    #  calculate the sp production rate
    production_rate_point_sp = production_CN_SLHL_sp * scaling_factor_sp * shielding_factor_field
    #  calculate the fm production rate
    production_rate_point_fm = production_CN_SLHL_fm * scaling_factor_fm * shielding_factor_field
    #  calculate the sm production rate
    production_rate_point_sm = production_CN_SLHL_sm * scaling_factor_sm * shielding_factor_field

    return production_rate_point_sp, production_rate_point_fm, production_rate_point_sm


def calculate_denudation_rate_point(latitude, longitude, elevation, concentration_CN, density, shielding_factor_field):
    """
    Calculate the denudation rate using the analytical method (Charreau et al., 2019).
    Input: 
        latitude [degrees]
        longitude [degrees]
        elevation [m]
        concentration_CN [atoms/g]
        density [g/cm3]
    Output:
        denudation_rate [cm/yr]     : denudation rate of the site.
        Note: this function is designed to constrain the initial k, 
        and it does not consider the decay constant in the cosmogenic 
        nuclide model (Lal,1999). Because this function is only used to 
        determine the initial k. And, if the decay constant is considered, 
        the denudation rates have to be determined by iteration algorithm, 
        here, it does not necessary.
    """

    # get the production rate of sp, fm, sm pathways at the site
    production_rate_point_sp, production_rate_point_fm, production_rate_point_sm = \
    calculate_production_rate_point(latitude, longitude, elevation, shielding_factor_field)

    # calulate the denudation rate without considering the decay constant
    denudation_rate = (production_rate_point_sp*attenuation_neutron \
                     + production_rate_point_fm*attenuation_fmuon \
                     + production_rate_point_sm*attenuation_smuon) / (density*concentration_CN)
    
    return denudation_rate


def calculate_production_rate_catchment(latitude, longitude, lat_array, DEM_array, shieldingfactor):
    """
    This function calculates the production rate for the catchment by each reaction pathway.
    Input:
        latitude [degrees]
        longitude [degrees]
        lat_array [degrees]: the latitude np.array of the catchment. 
        DEM_array [m]: numpy array
        shieldingfactor: numpy array, shielding factor of each pxiel.
    Output:
        production_rate_catchment_sp [numpy array] [atoms/g/yr]
        production_rate_catchment_fm [numpy array] [atoms/g/yr]
        production_rate_catchment_sm [numpy array] [atoms/g/yr]
    """

    # get coefficient for sp scaling factor calculation
    sea_level_P, sea_level_T, ALR = get_atmospheric_coefficients(latitude, longitude)
    a, b, c, d, e = get_Stone_coefficients(lat_array)

    # convert DEM array (DEM_array) into atmospheric pressure array (P_array)
    P_array = sea_level_P * np.exp(-0.03417 / ALR * (np.log(sea_level_T) - np.log(sea_level_T - ALR * DEM_array)))

    # calculate scaling factors
    #  calculate the scaling factor for sp (Stone, 2000)
    scaling_factor_sp = (a + b * np.exp(-P_array / 150) + c * P_array + d * P_array ** 2 + e * P_array ** 3)
    #  calculate the scaling factor for fm and sm (Braucher et al., 2011)
    scaling_factor_fm = np.exp((1013.25 - P_array) / atmospheric_attenuation_fm)
    scaling_factor_sm = np.exp((1013.25 - P_array) / atmospheric_attenuation_sm)

    # calculate the production rate for the catchment
    #  calculate the sp production rate
    production_rate_catchment_sp = production_CN_SLHL_sp * scaling_factor_sp * shieldingfactor
    #  calculate the fm production rate
    production_rate_catchment_fm = production_CN_SLHL_fm * scaling_factor_fm * shieldingfactor
    #  calculate the sm production rate
    production_rate_catchment_sm = production_CN_SLHL_sm * scaling_factor_sm * shieldingfactor

    return production_rate_catchment_sp, production_rate_catchment_fm, production_rate_catchment_sm


def get_utm_project_name(longitude, latitude):
    """
    get the projected coordinate system (UTM) for the catchment
      based on the entroid coordinate of the catchment.
    Inputs:
        longtitude [degrees]: centroid coordinate
        latitude [degrees]: controid coordinate
    Output:
        the cooresponding projected spatical reference
    """
    # determine UTM zone based on the input point
    utm_zone_number = int((longitude + 180) / 6) + 1  # Calculate UTM zone based on longitude
    
    # determine hemisphere (N for Northern Hemisphere, S for Southern Hemisphere)
    hemisphere = 'N' if latitude >= 0 else 'S'
    
    # create a spatial reference for the UTM zone
    utm_spatial_reference = arcpy.SpatialReference(f"WGS 1984 UTM Zone {utm_zone_number}{hemisphere}")
    
    return utm_spatial_reference


def newton_iteration(a, b, c, d, e, f, g, y, x0, tol=1e-7, max_iter=1000):
    """
    use newton iteration to constrain denudation rates from measued CN concentrations
    Inputs:
        a: mean production rate by sp
        b: decay constant
        c: density / attenuation_neutron
        d: mean production rate by fm
        e: density / attenuation_fm
        f: mean production rate by sm
        g: density / attenuation_sm
        y: CN concentrations
        x0: initial guess of denudation rates
    Output:
        catchment mean denudation rates
    """
    def func(x):
        # the original function f(x)
        return a / (b + c * x) + d / (b + e * x) + f / (b + g * x) - y

    def dfunc(x):
        # f'(x)
        return -a * c / (b + c * x) ** 2 - d * e / (b + e * x) ** 2 - f * g / (b + g * x) ** 2

    x = x0
    for i in range(max_iter):
        f_val = func(x)
        df_val = dfunc(x)

        if abs(f_val) < tol:
            return x
        if df_val == 0:  # to avoid zero
            raise ValueError("Derivative is zero, cannot continue iteration.")
        
        x_new = x - f_val / df_val
        
        if abs(x_new - x) < tol:
            return x_new
        x = x_new
    
    raise ValueError("Maximum number of iterations reached without convergence")