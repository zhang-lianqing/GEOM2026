# ==========================================================================================================
# denudation_conventional.py
# Purpose:      Calculate catchment-wide denudation rates using the conventional framework
#
# Author:       Lianqing Zhang (lianqingzhang2023@gmail.com)
#
# Created:      2026.3
# Copyright (c) 2026 Lianqing Zhang
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, provided that the above copyright notice and this
# permission notice shall be included in all copies or substantial portions of
# the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==========================================================================================================

import arcpy
import os
import sys
import tempfile
import shutil

# get the directory (cur_dir) of this script
cur_dir = os.path.dirname(os.path.abspath(__file__))
# add 'cur_dir' into the system path to access the 'data_base.py' and 'utility_functions.py'
sys.path.append(cur_dir)
from data_base import *
from utility_functions import *

# ==========================================================================================================

# check licenses
arcpy.CheckOutExtension('Spatial')
# clean up 'in memeory'
arcpy.Delete_management("in_memory")
# set environment
arcpy.env.overwriteOutput = True
# set temporary folder
temp_folder = tempfile.mkdtemp()

# ==========================================================================================================

# get parameters:
Input_catchments_shapefile = arcpy.GetParameterAsText(0)
Input_DEM_raster = arcpy.GetParameterAsText(1)
Density = float(arcpy.GetParameterAsText(2))
# CNs = arcpy.GetParameterAsText(3) # find it in data_base.py
Concentration_field = arcpy.GetParameterAsText(4)
Concentration_uncertainty_field = arcpy.GetParameterAsText(5)
Shielding_factor_field = arcpy.GetParameterAsText(6)
Shielding_factor_raster = arcpy.GetParameterAsText(7)

# ==========================================================================================================

# central coordinate 
arcpy.management.CalculateGeometryAttributes(Input_catchments_shapefile, [['cent_long', 'CENTROID_X'], ['cent_lat', 'CENTROID_Y']])

# add fields for results
arcpy.AddField_management(Input_catchments_shapefile, "Denu", "FLOAT", "", "", 50)
arcpy.AddField_management(Input_catchments_shapefile, "Denu_unc", 'FLOAT', '', '', 50)

# ==========================================================================================================

# total catchments
total_catchments = int(arcpy.GetCount_management(Input_catchments_shapefile)[0])
# set progress prompt
arcpy.SetProgressor("step", "Running...", 0, total_catchments, 1)

# ==========================================================================================================
# calculation
field_name = ["SHAPE@", "FID", "cent_long", "cent_lat", Concentration_field, Concentration_uncertainty_field, 
              Shielding_factor_field, "Denu", "Denu_unc"]

with arcpy.da.UpdateCursor(Input_catchments_shapefile, field_name) as cursor:
    # for row in cursor:
    for index, row in enumerate(cursor, start=1):
        geometry = row[0]
        FID = row[1]
        centroid_long = row[2]
        centroid_lat = row[3]
        concentration_CN = row[4]
        concentration_uncertainty = row[5]
        shielding_factor_field = row[6]

        # get the catchment's DEM
        DEM = arcpy.sa.ExtractByMask(Input_DEM_raster, geometry, 'INSIDE')
         # get DEM array.
        DEM_array = arcpy.RasterToNumPyArray(DEM, nodata_to_value=-9999)
        #  convert the DEM array into float data type.
        DEM_array = DEM_array.astype(float)
        #  then, conver the -9999 to NoData.
        DEM_array[DEM_array == -9999] = np.nan
        # get latitude array
        lat_array = get_coordinates_array(DEM, DEM_array)

        # get shielding factor array
        if Shielding_factor_raster:
            shielding_raster = arcpy.sa.ExtractByMask(Shielding_factor_raster, geometry, 'INSIDE')
            shieldingfactor_array = arcpy.RasterToNumPyArray(shielding_raster, nodata_to_value=-9999)
            shieldingfactor_array = shieldingfactor_array.astype(float)
            shieldingfactor_array[shieldingfactor_array == -9999] = np.nan
            # check shape
            if not np.array_equal(shieldingfactor_array.shape, DEM_array.shape):
                arcpy.AddError('Shielding factor raster has different shape from DEM.')
            shieldingfactor = shieldingfactor_array
        else:
            shieldingfactor = shielding_factor_field

        # calculate production rates by three pathways (sp, fm, sm) for each pixel in the catchment.
        #  the results are np arrays
        production_rate_point_sp, production_rate_point_fm, production_rate_point_sm = \
        calculate_production_rate_catchment(centroid_lat, centroid_long, lat_array, DEM_array, shieldingfactor)

        # calculate the denudation rate array and the primary denudation rate
        denudation_rate_array = (production_rate_point_sp*attenuation_neutron \
                               + production_rate_point_fm*attenuation_fmuon \
                               + production_rate_point_sm*attenuation_smuon) / (Density * concentration_CN)
        denudation_rate = np.nanmean(denudation_rate_array)
        
        # use newton iteration to determine the final denudation rates for catchments
        denudation_rate = newton_iteration(np.nanmean(production_rate_point_sp),
                                                  decay_constant_CN,
                                                  Density/attenuation_neutron,
                                                  np.nanmean(production_rate_point_fm),
                                                  Density/attenuation_fmuon,
                                                  np.nanmean(production_rate_point_sm),
                                                  Density/attenuation_smuon,
                                                  concentration_CN,
                                                  denudation_rate,
                                                  tol=1e-7, max_iter=1000)

        # calculate the denudation uncertainty (please refer to the code from Charreau et al.(2019))
        # uncertainty of production rate arrays
        uncertainty_production_rate_sp = unc_production_sp * production_rate_point_sp
        uncertainty_production_rate_fm = unc_production_fm * production_rate_point_fm
        uncertainty_production_rate_sm = unc_production_sm * production_rate_point_sm
        # uncertianty of CNs concentration: concentration_uncertainty
        # propagated uncertainty arrays
        unc_A = ((concentration_uncertainty / (concentration_CN ** 2)) * (denudation_rate_array / concentration_CN)) ** 2
        unc_B = (uncertainty_production_rate_sp * attenuation_neutron / (concentration_CN * Density)) ** 2
        unc_C = (uncertainty_production_rate_fm * attenuation_fmuon / (concentration_CN * Density)) ** 2
        unc_D = (uncertainty_production_rate_sm * attenuation_smuon / (concentration_CN * Density)) ** 2
        uncertainty_denudation_array = np.sqrt(unc_A + unc_B + unc_C + unc_D)
        uncertainty_denudation = np.nanmean(uncertainty_denudation_array)
        
        # add the results into the attribute table
        row[7] = denudation_rate * 10000 # convert the unit from cm/yr to mm/kyr
        row[8] = uncertainty_denudation * 10000

        # update cursor
        cursor.updateRow(row)
        arcpy.SetProgressorPosition(index)
        arcpy.SetProgressorLabel(f"Processing row {index}/{total_catchments}")

# ==========================================================================================================
shutil.rmtree(temp_folder)
arcpy.Delete_management('in_memory')
